

void member_insert(char *, char *, char *);
void member_update(int, char *, char *, char *);
int member_idcheck(char*);
int member_login(char*, char*);