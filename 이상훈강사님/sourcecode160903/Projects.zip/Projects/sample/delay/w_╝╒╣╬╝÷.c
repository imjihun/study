#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int x, y, z;
	srand((int)time(NULL));
	x = rand()%1000;
	y = rand()%1000;
	z = rand()%1000;

	printf("%d %d %d",x, y, z );
	
	

	
	
	
}