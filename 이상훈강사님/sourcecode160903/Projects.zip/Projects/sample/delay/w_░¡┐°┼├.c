#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
	int x,y,z,ran;
	while(1){
		ran=rand()%1000+1;
		printf("%d%d%d \t",x,y,z);
	}
	return 0;
}